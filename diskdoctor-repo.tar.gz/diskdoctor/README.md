# DiskDoctor

**Forensic disk scanner + evidence-based repair engine, in one dependency-free Python file.**

DiskDoctor grew out of a real recovery job: VMware VMDKs that had been repaired and re-attached in Windows, one of which had gone RAW and another whose Veeam `.vbk` backup was reading corrupt. It answers three questions for a disk you're not sure about — *what partition scheme is this, what filesystem is on it, and how deep does the damage go* — and only then, separately, asks whether it's safe to write anything.

Single file, Python 3.8+, **zero third-party dependencies**. Runs on Windows (primary target — raw `\\.\PhysicalDriveN` access), Linux (`/dev/sdX`), or directly against a raw disk image.

> پیام‌های ابزار به‌صورت پیش‌فرض فارسی است (`--lang en` برای انگلیسی). این ابزار برای کار روی دیسک‌های VMware/Veeam که بعد از تعمیر VMDK در ویندوز Attach شده‌اند نوشته شده.

---

## Why this exists

Most disk-repair tools either (a) fix things without telling you why they think it's safe, or (b) dump raw signatures at you and leave the judgment call to you. Neither is good enough when the data is a production Veeam repository and every write is a one-way door.

DiskDoctor keeps three concerns strictly apart:

```
Scanner  →  Evidence Builder  →  Write Gate  →  Patch Transaction  →  Journal
(read)      (score, don't act)   (hard rules)    (fsync before write)  (byte-exact undo)
```

A repair action never gets to decide for itself that a candidate looks trustworthy. It asks the evidence layer, which either hands back proof or refuses — there is no soft fallback when proof is missing.

## What it does

- **Detects** GPT / MBR / superfloppy / RAW partition schemes, and NTFS, ReFS, exFAT, FAT12/16/32, ext2/3/4, XFS, Btrfs, Linux swap, LVM2, HFS+, APFS, ISO9660, VMFS, BitLocker.
- **Scores every candidate partition** on independent, inspectable signals (`--explain` prints all of them): does it come from a partition table, does its boot sector's own BPB fields agree with each other, does a backup copy exist and match, is the declared volume length actually provable from a source on disk — not just "a signature was seen here".
- **Never guesses a partition's length.** A filesystem signature alone is not enough to trust an offset; a lone backup boot sector (e.g. from a destroyed NTFS volume) is specifically checked so it isn't mistaken for the start of a new volume.
- **Refuses writes without proof.** Every repair is either `SAFE_RESTORE` (copying an existing, valid structure already on the disk — GPT backup → primary, a validated mirror boot sector) or `INFERRED_REBUILD` (synthesizing a table from scratch, which needs an explicit `--allow-inferred` on top of `--apply`). Disk-level blockers — a GPT whose geometry doesn't match the real disk size, a container file instead of a raw disk, a system disk — stop every synthesis outright.
- **Triages damage depth** (`--triage`) instead of just saying "boot sector missing": reads the first sectors, sweeps the volume tail for surviving filesystem structures, samples the whole partition for a damage map, walks forward for the first recoverable structure, and — critically — can compare against a **known-healthy control volume** so raw entropy isn't mistaken for evidence of an overwrite (a repository full of compressed backups is high-entropy *by design*).
- **One-shot mode** (`--auto`): scan every disk, go deep only where the table can't describe the disk, triage everything that isn't provably healthy, pick a control volume automatically, write one text report and one JSON file. Nothing is written to any disk.
- **Journals before writing.** The journal is created and fsynced *before* the first byte changes, with per-patch status (`pending` → `done`). A crash mid-write leaves a journal that says exactly what landed, and `--undo` reverses it byte-for-byte — including a partial one.
- **Images forensically**, not silently. Read failures retry, then descend to sector granularity; anything still unreadable is recorded in an explicit `.badmap.json` with a recognizable fill pattern — never a quiet zero that could be mistaken for real data.
- **Self-tests itself** against synthetic disk images built from the on-disk specifications (not from the parser's own assumptions) — see [Testing](#testing).

## What it deliberately does not do

- No ReFS structure is ever written. ReFS repair is refused at the sector level; DiskDoctor gathers evidence (including a volume-header copy near the end of the volume, and duplicated `SUPB`/`CHKP` superblocks) and routes you to `refsutil salvage` — with a build-version compatibility check, because `refsutil`'s ReFS-version ceiling is tied to the Windows build it shipped with, and its failure message ("volume does not contain a recognized file system") is misleading when the real cause is a version mismatch, not corruption.
- No dynamic disks (LDM) / Storage Spaces reconstruction — rebuilding the partition table does not bring back logical volumes.
- No data recovery from a genuinely overwritten volume. If the evidence says the volume body was overwritten (not just its boot sector), DiskDoctor says so and points at the likely cause (e.g. a wrong VMDK extent mapping) instead of pretending a repair is possible.

## Quick start

```powershell
# Windows, Run as Administrator
chcp 65001
python diskdoctor.py --self-test          # 150+ synthetic tests, touches no real disk
python diskdoctor.py --list               # enumerate disks
python diskdoctor.py --auto --all         # read-only, everything, one text+JSON report
```

```bash
# Linux
sudo python3 diskdoctor.py --disk /dev/sdb --scan --explain --triage

# Directly on a raw image file, no elevated privileges needed
python3 diskdoctor.py --disk /path/to/flat.img --scan --explain
```

Full switch reference is embedded in the tool itself:

```
python diskdoctor.py --help-full
```

## The write gate, concretely

| Gate | Meaning | Requires |
|---|---|---|
| `SAFE_RESTORE` | Source is a valid structure that already exists on this disk. No inference. | `--apply` |
| `INFERRED_REBUILD` | Structure is synthesized from evidence. | `--apply --allow-inferred` |
| `BLOCKED` | Refused, with the exact reason printed. | (nothing bypasses this except `--force`, which also overrides disk-level blockers) |

Repair actions:

`gpt-restore-primary`, `gpt-restore-backup`, `gpt-fix-crc`, `gpt-fix-geometry`, `mbr-write-protective`, `mbr-rebuild`, `gpt-rebuild`, `vbr-restore`, `vbr-restore-reverse`, `parttype-fix`, plus the Windows-side `chkdsk`, `refsutil`, `rescan`.

GPT restores are **byte-for-byte**: `gpt-restore-primary` copies the backup's entry array verbatim and transplants only the location fields (`MyLBA`, `AlternateLBA`, `PartitionEntryLBA`) and CRC into the header — `entry_size`, revision, and reserved bytes are never regenerated.

## Recommended workflow

```powershell
python diskdoctor.py --self-test
python diskdoctor.py --list
python diskdoctor.py --disk 3 --scan --explain --triage --json report.json
python diskdoctor.py --disk 3 --image-out D:\img\disk3.img      # before any --apply
python diskdoctor.py --disk 3 --action gpt-restore-primary               # preview
python diskdoctor.py --disk 3 --action gpt-restore-primary --apply       # commit
python diskdoctor.py --undo diskdoctor_backups\journal_XXXX.json         # if wrong
```

Or just:

```powershell
python diskdoctor.py --auto --all
```

## Testing

```
python diskdoctor.py --self-test
```

Builds synthetic MBR/GPT/NTFS/exFAT/FAT32/ReFS images from the written specification (not from what the parser itself assumes — e.g. the FAT32 test image deliberately places a decoy value at the offset a buggy parser would read, so the test only passes if `BPB_BkBootSec` is actually read from `0x32`), then exercises the full pipeline: partition/filesystem detection, evidence scoring, the write gate refusing unproven rebuilds, byte-for-byte GPT restores, journal-before-write with crash-partial undo, forensic imaging with injected read failures, and the triage entropy-control logic against both a genuinely overwritten volume and a healthy one that merely happens to be full of compressed data. Nothing in the suite touches a real disk.

## Exit codes

| Code | Meaning |
|---|---|
| 0 | success |
| 1 | general error |
| 2 | bad argument |
| 3 | permission denied |
| 4 | target not found |
| 5 | cancelled by user |
| 6 | self-test failed |
| 7 | write refused by the gate |

## Safety notes

- Default is always read-only. Nothing is written without `--apply`.
- Image the disk first (`--image-out`) before any `--apply`.
- If the disk makes unusual noise or SMART is failing, stop — go straight to data recovery, not structural repair.
- Structural repair restores *structure*, not data. If the filesystem's own metadata is gone, the next step is file-level recovery, not another repair attempt.

## License

MIT — see [LICENSE](LICENSE).
